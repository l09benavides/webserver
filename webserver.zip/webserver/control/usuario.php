<?php
class usuario(){
	var $id;
	var $cedula;
	var $nombre;
	var $apellidos;
	var $telefono;
    var $email;
	var $usuario;
	var $contrasena;
	var $rol;

	public function InsertarUsuario(){

	}

	public function ActualizarUsuario(){

	}

	public function EliminarUsuario(){

	}

	public function ListarUsuario(){

	}

	public function BuscarUsuario(){

	}	

}

?>

