<?php
class compra(){
	var $id;
	var $id_usuario;
	var $id_usuario;
	var $num_compra;
	var $fecha_compra;

	function InsertarArticulo(){

	}

	function ListarArticulo(){

	}

	function BuscarArticulo(){

	}	

}

?>

