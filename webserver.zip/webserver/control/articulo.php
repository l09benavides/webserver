<?php
class articulo(){
	var $id;
	var $codigo;
	var $marca;
	var $descripcion;
	var $precio;
       	var $cantidad;

	function InsertarArticulo(){

	}

	function ListarArticulo(){

	}

	function BuscarArticulo(){

	}	

}

?>

