<?php
require_once(ABSPATH . "conn/Conex.php");
require_once(ABSPATH . "model/model.php");
class prefiles_model extends model
{
//------------------------------------------------------------------------------
// Attributes declarations
//------------------------------------------------------------------------------
    private $table;
//------------------------------------------------------------------------------
// Constructors declarations
//------------------------------------------------------------------------------
    public function __construct()
    {
        $this->table = "prefiles";
    }
    public function __destruct()
    { }
    public function asignValues ()
    {
    }
//------------------------------------------------------------------------------
// Set & Get declarations
//------------------------------------------------------------------------------
    public function getTable()
    {
        return $this->table;
    }
}
?>