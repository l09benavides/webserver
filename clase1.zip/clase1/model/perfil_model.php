<?php
require_once(ABSPATH . "conn/conexion.php");

class perfil_model 
{
//------------------------------------------------------------------------------
// Attributes declarations
//------------------------------------------------------------------------------
    private $table;
    private $idperfil;
    private $perfil;
//------------------------------------------------------------------------------
// Constructors declarations
//------------------------------------------------------------------------------
    public function __construct()
    {
        $this->table = "perfil";
    }
    public function __destruct()
    { }
    public function asignValues ($idperfilp, $perfilp)
    {
        $this->idperfil = $idperfilp;
        $this->perfil = $perfilp;
    }
//------------------------------------------------------------------------------
// Set & Get declarations
//------------------------------------------------------------------------------
    public function getTable()
    {
        return $this->table;
    }
	//------------------------------------------------------------------------------
	// Field: idperfil type: int 
    public function setidperfil( $idperfilp )
    {
        $this->idperfil = $idperfilp;
    }
	// Field: idperfil return type: int 
    public function getidperfil()
    {
        return $this->idperfil;
    }
	//------------------------------------------------------------------------------
	// Field: perfil type: varchar 
    public function setperfil( $perfilp )
    {
        $this->perfil = $perfilp;
    }
	// Field: perfil return type: varchar 
    public function getperfil()
    {
        return $this->perfil;
    }
}
?>