<?php
require_once(ABSPATH . "conn/conexion.php");

class usuarios_model
{
//------------------------------------------------------------------------------
// Attributes declarations
//------------------------------------------------------------------------------
    private $table;
    private $idusuario;
    private $user;
    private $pass;
    private $nombre;
    private $idperfil;
    private $estado;
//------------------------------------------------------------------------------
// Constructors declarations
//------------------------------------------------------------------------------
    public function __construct()
    {
        $this->table = "usuarios";
    }
    public function __destruct()
    { }
    public function asignValues ($idusuariop, $userp, $passp, $nombrep, $idperfilp, $estadop)
    {
        $this->idusuario = $idusuariop;
        $this->user = $userp;
        $this->pass = $passp;
        $this->nombre = $nombrep;
        $this->idperfil = $idperfilp;
        $this->estado = $estadop;
    }
//------------------------------------------------------------------------------
// Set & Get declarations
//------------------------------------------------------------------------------
    public function getTable()
    {
        return $this->table;
    }
	//------------------------------------------------------------------------------
	// Field: idusuario type: int 
    public function setidusuario( $idusuariop )
    {
        $this->idusuario = $idusuariop;
    }
	// Field: idusuario return type: int 
    public function getidusuario()
    {
        return $this->idusuario;
    }
	//------------------------------------------------------------------------------
	// Field: user type: varchar 
    public function setuser( $userp )
    {
        $this->user = $userp;
    }
	// Field: user return type: varchar 
    public function getuser()
    {
        return $this->user;
    }
	//------------------------------------------------------------------------------
	// Field: pass type: varchar 
    public function setpass( $passp )
    {
        $this->pass = $passp;
    }
	// Field: pass return type: varchar 
    public function getpass()
    {
        return $this->pass;
    }
	//------------------------------------------------------------------------------
	// Field: nombre type: varchar 
    public function setnombre( $nombrep )
    {
        $this->nombre = $nombrep;
    }
	// Field: nombre return type: varchar 
    public function getnombre()
    {
        return $this->nombre;
    }
	//------------------------------------------------------------------------------
	// Field: idperfil type: int 
    public function setidperfil( $idperfilp )
    {
        $this->idperfil = $idperfilp;
    }
	// Field: idperfil return type: int 
    public function getidperfil()
    {
        return $this->idperfil;
    }
	//------------------------------------------------------------------------------
	// Field: estado type: varchar 
    public function setestado( $estadop )
    {
        $this->estado = $estadop;
    }
	// Field: estado return type: varchar 
    public function getestado()
    {
        return $this->estado;
    }
}
?>