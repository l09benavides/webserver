<?php 

class model
{

	public function Select()
	{
		# code...
	}

	public function Update()
	{
		# code...
	}

	public function Delete()
	{
		# code...
	}

	public function Insert()
	{
		# code...
	}
}

 ?>