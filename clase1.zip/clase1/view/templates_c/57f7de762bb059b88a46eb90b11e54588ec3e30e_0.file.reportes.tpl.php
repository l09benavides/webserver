<?php
/* Smarty version 3.1.31, created on 2017-11-02 03:35:15
  from "C:\wamp\www\clase1\view\templates\reportes.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_59fa84633558e9_28314426',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '57f7de762bb059b88a46eb90b11e54588ec3e30e' => 
    array (
      0 => 'C:\\wamp\\www\\clase1\\view\\templates\\reportes.tpl',
      1 => 1509585156,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_59fa84633558e9_28314426 (Smarty_Internal_Template $_smarty_tpl) {
?>
reportes<?php }
}
