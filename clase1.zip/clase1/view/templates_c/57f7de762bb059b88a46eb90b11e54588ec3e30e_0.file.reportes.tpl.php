<?php
/* Smarty version 3.1.31, created on 2017-11-23 03:32:04
  from "C:\wamp\www\clase1\view\templates\reportes.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5a163324193cb2_69930917',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '57f7de762bb059b88a46eb90b11e54588ec3e30e' => 
    array (
      0 => 'C:\\wamp\\www\\clase1\\view\\templates\\reportes.tpl',
      1 => 1511404320,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5a163324193cb2_69930917 (Smarty_Internal_Template $_smarty_tpl) {
?>
<center><h1>Reportes</h1></center>
<br>
<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['data1']->value, 'valor');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['valor']->value) {
?>
	valor: <?php echo $_smarty_tpl->tpl_vars['valor']->value;?>
<br>
<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);
?>





<h2>Multiarray Asociado</h2>

<table>
	<tr bgcolor="#3374FF" >
		<th>ID</th>
		<th>Nombre</th>
		<th>Apellido 1</th>
		<th>Apellido 2</th>
		<th>Estado</th>
		<th>Accion</th>
	</tr>
	
	<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['data2']->value, 'usuario', false, NULL, 'n', array (
));
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['usuario']->value) {
?>
		<tr>
			<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['usuario']->value, 'valor');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['valor']->value) {
?>
				<td><?php echo $_smarty_tpl->tpl_vars['valor']->value;?>
</td>
			<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);
?>

			<td><a href="#"><button>Editar</button></a></td>
		</tr>
	<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);
?>


</table>

<h2>Multiarray Asociado DB</h2>

<table>
	<tr bgcolor="#3374FF" >
		<th>ID</th>
		<th>Usuario</th>
		<th>Passowrd</th>
		<th>Nombre</th>
		<th>Id Perfil</th>
		<th>Estado</th>
		<th>Accion</th>
	</tr>
	
	<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['datadb']->value, 'usuario', false, NULL, 'n', array (
));
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['usuario']->value) {
?>
		<tr>
			<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['usuario']->value, 'valor');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['valor']->value) {
?>
				<td><?php echo $_smarty_tpl->tpl_vars['valor']->value;?>
</td>
			<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);
?>

			<td><a href="#"><button>Editar</button></a></td>
		</tr>
	<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);
?>


</table><?php }
}
