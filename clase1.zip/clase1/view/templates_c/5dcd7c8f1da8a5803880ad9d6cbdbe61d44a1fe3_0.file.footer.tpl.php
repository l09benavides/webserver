<?php
/* Smarty version 3.1.31, created on 2017-10-26 04:56:22
  from "C:\wamp\www\clase1\view\templates\footer.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_59f14ed6381cb3_31428332',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '5dcd7c8f1da8a5803880ad9d6cbdbe61d44a1fe3' => 
    array (
      0 => 'C:\\wamp\\www\\clase1\\view\\templates\\footer.tpl',
      1 => 1508983527,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_59f14ed6381cb3_31428332 (Smarty_Internal_Template $_smarty_tpl) {
?>
</BODY>
</HTML>
<?php }
}
