<?php /* Smarty version 3.1.31, created on 2017-10-26 04:56:22
         compiled from "C:\wamp\www\clase1\control\configs\test.conf" */ ?>
<?php
/* Smarty version 3.1.31, created on 2017-10-26 04:56:22
  from "C:\wamp\www\clase1\control\configs\test.conf" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_59f14ed6084b61_60168377',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'ebec922eba888b4b8a3f678311dc9e5246c7f99d' => 
    array (
      0 => 'C:\\wamp\\www\\clase1\\control\\configs\\test.conf',
      1 => 1508983527,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_59f14ed6084b61_60168377 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->smarty->ext->configLoad->_loadConfigVars($_smarty_tpl, array (
  'sections' => 
  array (
    'setup' => 
    array (
      'vars' => 
      array (
        'bold' => true,
      ),
    ),
  ),
  'vars' => 
  array (
    'title' => 'Welcome to Smarty!',
    'cutoff_size' => 40,
  ),
));
}
}
