<?php
/* Smarty version 3.1.31, created on 2017-11-02 03:35:12
  from "C:\wamp\www\clase1\view\templates\home.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_59fa8460eba061_95845286',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'b4fb6ae2d8338a6043da408fa8b63e08546a216e' => 
    array (
      0 => 'C:\\wamp\\www\\clase1\\view\\templates\\home.tpl',
      1 => 1509585157,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_59fa8460eba061_95845286 (Smarty_Internal_Template $_smarty_tpl) {
?>
home<?php }
}
