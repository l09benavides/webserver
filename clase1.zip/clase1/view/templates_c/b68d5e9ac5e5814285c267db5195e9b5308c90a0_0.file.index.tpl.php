<?php
/* Smarty version 3.1.31, created on 2017-10-26 04:57:05
  from "C:\wamp\www\clase1\view\templates\index.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_59f14f01b5ef60_53882830',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'b68d5e9ac5e5814285c267db5195e9b5308c90a0' => 
    array (
      0 => 'C:\\wamp\\www\\clase1\\view\\templates\\index.tpl',
      1 => 1508986621,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_59f14f01b5ef60_53882830 (Smarty_Internal_Template $_smarty_tpl) {
?>
<h1><?php echo $_smarty_tpl->tpl_vars['kNombre']->value;?>
</h1>

<?php }
}
