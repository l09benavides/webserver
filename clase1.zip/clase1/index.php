<?php

//Muestra error en caso de error y continua
//include "control/controller_persona.php";
//include_once "control/controller_persona.php"; //el once, revisa si esta cargado en memoria


//Para Ejecucion en caso de error
//require "control/controller_persona.php";
require_once "control/controller_persona.php";

$insIndex = new Controller_persona();

$insIndex->mostrar();

?>