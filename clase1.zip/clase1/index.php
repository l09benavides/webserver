<?php

//Muestra error en caso de error y continua
//include "control/controller_persona.php";
//include_once "control/controller_persona.php"; //el once, revisa si esta cargado en memoria


//Para Ejecucion en caso de error
//require "control/controller_persona.php";
require_once "control/controller_persona.php";

$insIndex = new Controller_persona();


if(isset($_REQUEST['accion'])){
	//aqui estara el dinamismo
	$opt = $_REQUEST['accion'];

	switch ($opt) {
		case 1:
			$insIndex->openHome();
			break;
		case 2:
			$insIndex->openCatalogo();
			break;
		case 3:
			$insIndex->openReporte();
		break;
		default:
			echo "error";
			break;
	}
}else{
	$insIndex->mostrar();
}

?>