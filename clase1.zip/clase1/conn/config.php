<?php 
	define("SERVER", "localhost");
	define("PASS", "");
	define("USER", "root");
	define("DB", "clase1");


 ?>