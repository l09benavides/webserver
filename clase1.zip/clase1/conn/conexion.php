<?php 

require_once("config.php");

/**
* 
*/
class Conexion
{
	private $link;


	public function __construct(){}

	public function connectar(){
		$this->link = mysqli_connect(SERVER,USER,PASS,DB);

		if (!$this->link){
			echo "Error Connectando a la Base de Datos: ".$this->link->connect_error;
		}
	}

	public function CloseConn(){
		mysqli_close($this->link);
	}

	public function getLink(){
		return $this->link;
	}

	public function query($query){
		try {
			$this->connectar();
			$results = $this->link->query($query);
			$this->CloseConn();
			return $results;

		} catch (Exception $e) {
			echo "Error: ".$e;
		}
	}
}

 ?>