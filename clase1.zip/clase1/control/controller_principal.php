<?php

require_once "/libs/smarty/config_smarty.php";
require_once "/control/usuarios_controller.php";

class Controller_principal{


		//Clase encapsulada get's y set´s para los atributos privados

		// por defecto en privada
		// ninguna clase tiene que accederlo directamente
		private $nombre;
		private $apellidos;
		private $edad;
		private $ins;
		
		//Singleton
		public static $instancia;

		public static function getInstance(){
			if(!self::$instancia instanceof self){
				return self::$instancia = new self;
			}else{
				return self::$instancia;
			}
		}		
		//singleton
		

		//Constructor se usa por defecto
		public function __construct(){
			//al ser orientado a objectos se usa this, y la variable no usa $
			$this->nombre = "";
			$this->apellidos = "";
			$this->edad = 0;
			$this->ins = new config_smarty();
			$this->ins->setRutas();
		}

		//get's y set's
		public function getNombre(){
			return $this->nombre;
		}	

		public function setNombre($nuevoNombre){
			$this->nombre = $nuevoNombre;
		}

		public function getApellidos(){
			return $this->apellidos;
		}

		public function setApellidos($nuevoApellidos){
			$this->apellidos = $nuevoApellidos;
		}

		public function getEdad(){
			return $this->edad;
		}

		public function setEdad($nuevoEdad){
			$this->edad = $nuevoEdad;
		}

		

		//Inician Metodos
		public function saludar(){
			
		}



		public function despedir(){

		}

		public function mostrar(){
			
			$this->ins->setAssign("kNombre","Luis");
			$this->ins->setAssign("item1","Inicio");
			$this->ins->setAssign("item2","Catalogos");
			$this->ins->setAssign("item3","Reportes");
			$this->ins->exeDisplay("index.tpl");

		}


		public function openHome(){
			$this->ins->exeDisplay("home.tpl");
		}

		public function openCatalogo(){
			$this->ins->exeDisplay("catalogos.tpl");
		}

		public function openReporte(){
			$persona = new usuarios_controller();
			$arrData = $persona->getAllData();

			$this->ins->setAssign("data1", $this->demoArray());
			$this->ins->setAssign("data2", $this->demo2Array());
			$this->ins->setAssign("datadb", $arrData);
			$this->ins->exeDisplay("reportes.tpl");
		}

		public function demoArray(){
			$arr = array(123,123,13,123,14);
			return $arr;
		}


		public function demo2Array(){
			$arrDato2="";
			$usu1 = array("id"=>1,"nombre"=>"Luis","apellido1"=>"Benavides","apellido2"=>"Rivera","estado"=>"Activo");
			$usu2 = array("id"=>2,"nombre"=>"Ana","apellido1"=>"Mendoza","apellido2"=>"Mendoza","estado"=>"Activo");
			$usu3 = array("id"=>3,"nombre"=>"Mauren","apellido1"=>"Rodriguez","apellido2"=>"Suarez","estado"=>"Inactivo");
			$arrDato2[]=$usu1;
			$arrDato2[]=$usu2;
			$arrDato2[]=$usu3;
			return $arrDato2;
		}

}

?>