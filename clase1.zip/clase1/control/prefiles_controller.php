<?php
// header("Access-Control-Allow-Origin: *");
// header("Access-Control-Allow-Headers: *");
/**
 * Seasons Controller
 * @category Controller
 * @package Clase 1
 * @version 1.0
 * @author  Royner Luna
 * @copyright Copyright (c) 2017
 * 
 */
require_once( ABSPATH . "libs/controller.php" );
class prefiles_controller extends controller {
    //------------------------------------------------------------------------------
    //------------------------------------------------------------------------------
    // Attributes declarations
    //------------------------------------------------------------------------------
    //------------------------------------------------------------------------------
    //------------------------------------------------------------------------------
    //------------------------------------------------------------------------------
    // Constructors declarations
    //------------------------------------------------------------------------------
    //------------------------------------------------------------------------------
    public function __construct()
    { 
        try { 
            parent::__construct();
            parent::loadModel("prefiles_model", "maintance");
        } 
        catch (Exception $e) { 
            $this->registerLog("prefiles_controler");
            return false;
        }
    }
    public function __destruct()
    { }
    //------------------------------------------------------------------------------
    //------------------------------------------------------------------------------
    // Base methods
    //------------------------------------------------------------------------------
    //------------------------------------------------------------------------------
    //------------------------------------------------------------------------------
    //------------------------------------------------------------------------------
    // Procedures & functions declarations
    //------------------------------------------------------------------------------
    //------------------------------------------------------------------------------
    public function getData()
    { 
        $optionsBottom   =
            "<button type='button' data-action='delete' class='btn btn-sm btn-success noMargin'>" . 
            "   <i class='fa fa-trash'></i>" . 
            "</button>";
        $arrayData = array(); 
        $list = $this->model->selectAllData($this->model);
        foreach( $list as $row ) :
            $c = false;
            if( $c ) 
                $classSelector = "gradeX";
            else
                $classSelector = "gradeU";
            $c = !$c;
            array_push( $arrayData, array( 
                "DT_RowId"          => strval($row["CODIGO"]),
                "DT_RowClass"       => $classSelector,
                "options" 			=> $optionsBottom
           	));
        endforeach;
        $arrList["data"] = $arrayData;
        return json_encode($arrList);
    }
}
if( defined('DEBUGMODE') && DEBUGMODE  ) { }
if(isset($_POST['action'])) { 
    $controller = new prefiles_controller();
    switch ($_POST['action']) { 
        case 'getTableData':
            echo $controller->getData();
            break;
    }
}
?>