<?php

require_once "/libs/smarty/config_smarty.php";

class Controller_persona{


		//Clase encapsulada get's y set´s para los atributos privados

		// por defecto en privada
		// ninguna clase tiene que accederlo directamente
		private $nombre;
		private $apellidos;
		private $edad;

		//Constructor se usa por defecto
		public function __construct(){
			//al ser orientado a objectos se usa this, y la variable no usa $
			$this->nombre = "";
			$this->apellidos = "";
			$this->edad = 0;
		}

		//get's y set's
		public function getNombre(){
			return $this->nombre;
		}	

		public function setNombre($nuevoNombre){
			$this->nombre = $nuevoNombre;
		}

		public function getApellidos(){
			return $this->apellidos;
		}

		public function setApellidos($nuevoApellidos){
			$this->apellidos = $nuevoApellidos;
		}

		public function getEdad(){
			return $this->edad;
		}

		public function setEdad($nuevoEdad){
			$this->edad = $nuevoEdad;
		}

		

		//Inician Metodos
		public function saludar(){
			
		}



		public function despedir(){

		}

		public function mostrar(){
			$ins = new config_smarty();
			$ins->setRutas();
			$ins->setAssign("kNombre","Luis");
			$ins->exeDisplay("index.tpl");

		}


}

?>