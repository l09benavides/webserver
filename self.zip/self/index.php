<?php

/**
* self y ::
*
*class index
*{
*	
*	const CONST_NOMBRE = "Universidad Fidelitas";
*
*	public function mostrar() {
*		echo self::CONST_NOMBRE;
*	}
*
*}
*
*
*class Index_Hijo extends index
*{
*	public static $dos="HEEEEEEEEE"; //no son instanciables
*	
*	public static function imprimir() {
*		echo parent::CONST_NOMBRE;
*		echo "<br>";
*		echo self::$dos;
*	}
*}
*
*$i = new index();
*i->mostrar();
*
*
*echo "<br>Fuera de la clase: ".index::CONST_NOMBRE;
*$nombreClase = "Index_Hijo";
*
*$nombreClase::imprimir();
*
**/





/**
* Singleton
*/
class Index
{
	public static $instancia;

	public static function getInstance(){
		if(!self::$instancia instanceof self){
			return self::$instancia = new self;
		}else{
			return self::$instancia;
		}
	}

	public function Iniciar(){
		echo "Hola";
	}
}


$inst = Index::getInstance();

$inst->Iniciar();






?>