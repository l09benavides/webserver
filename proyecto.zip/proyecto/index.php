<?php 
require_once("control/login_controller.php");

$insLogin = login_controller::getInstance();
if (isset($_REQUEST['u'])) {
	$insLogin->validarLogin($_REQUEST['u'],$_REQUEST['p']);
}else{
	$insLogin->mostrarFrm();
}

 ?>