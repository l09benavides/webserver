<?php 
require_once("control/login_controller.php");
require_once("control/usuario_controller.php");

$insLogin = login_controller::getInstance();
$insUsuario = new usuario_controller();

if (isset($_REQUEST['accion'])) {
	$opt = $_REQUEST['accion'];

	switch ($opt) {
		case 1:
			if (isset($_REQUEST['u'])) {
				$insLogin->validarLogin($_REQUEST['u'],$_REQUEST['p']);
			}
			break;
		case 2:
			break;
		case 3:
			$insUsuario->mostrarFrm();
		break;
		case 4:
			$insReporte->mostrarFrm();
		break;
		case 5:
			$insUsuario->crearUsuario();
		break;
		default:
			echo "error";
			break;
	}
	unset($_REQUEST['accion']);
}else{
	$insLogin->mostrarFrm();
}
 ?>