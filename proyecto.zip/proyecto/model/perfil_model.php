<?php 
require_once("conn/conexion.php");

class perfil_model 
{
	private $insConexion;

	public function __construct()
	{
		$this->insConexion = new conexion();
	}


	public function getPerfiles(){

		$sql = "Select idperfil,perfil ";
		$sql .= "From perfil ";

		$mysqli = $this->insConexion->getLink();

		$rs= $mysqli->query($sql);
		$Lineas=array();

		foreach ($rs as $row) :
			$Linea=array();
			$Linea['ID']=$row["idperfil"];
			$Linea['PERFIL']=$row["perfil"];
			$Lineas[]=$Linea;
		endforeach;
		return $Lineas;

		$mysqli->closeConn();
	}
}
 ?>