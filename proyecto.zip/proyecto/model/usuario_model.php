<?php 
require_once("conn/conexion.php");

class usuario_model 
{
	private $insConexion;

	public function __construct()
	{
		$this->insConexion = new conexion();
	}


	public function crearUsuario(){

		$nombre = $_REQUEST['nombre'];
		$usuario = $_REQUEST['usuario'];
		$pass = $_REQUEST['pass'];
		$perfil = $_REQUEST['perfil'];
		$estado = $_REQUEST['estado'];

		$sql = "insert into usuarios ";
		$sql .= "(user,pass,nombre,idperfil,estado) ";
		$sql .= "values (";
		$sql .= "'".$usuario."',";
		$sql .= "'".$pass."',";
		$sql .= "'".$nombre."',";
		$sql .= "'".$perfil."',";
		$sql .= "'".$estado."'";
		$sql .= ")";

		$mysqli = $this->insConexion->getLink();

		if($rs= $mysqli->query($sql)){
			return true;
		}else{
			return False;
		}
		


		$mysqli->closeConn();
	}
}
 ?>