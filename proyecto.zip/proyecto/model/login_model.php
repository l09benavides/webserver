<?php 
require_once("conn/conexion.php");

class login_model 
{
	private $insConexion;

	public function __construct()
	{
		$this->insConexion = new conexion();
	}


	public function vallogin($usuario,$passowrd){

		$sql = "Select count(*) total ";
		$sql .= "From usuarios ";
		$sql .= "where user='".$usuario."'";
		$sql .= "and pass='".$passowrd."'";

		$mysqli = $this->insConexion->getLink();

		$rs= $mysqli->query($sql);
		$totallineas=0;
		foreach ($rs as $row) :
			$totallineas=$row["total"];
		endforeach;

		if ($totallineas==1) {
			return true;
		}else{
			return false;
		}

		$mysqli->closeConn();
	}
}
 ?>