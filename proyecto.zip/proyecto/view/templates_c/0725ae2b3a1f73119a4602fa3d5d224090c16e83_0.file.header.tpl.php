<?php
/* Smarty version 3.1.31, created on 2017-10-26 04:56:22
  from "C:\wamp\www\clase1\view\templates\header.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_59f14ed60fafd2_38018685',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '0725ae2b3a1f73119a4602fa3d5d224090c16e83' => 
    array (
      0 => 'C:\\wamp\\www\\clase1\\view\\templates\\header.tpl',
      1 => 1508983527,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_59f14ed60fafd2_38018685 (Smarty_Internal_Template $_smarty_tpl) {
?>
<HTML>
<HEAD>
<TITLE><?php echo $_smarty_tpl->tpl_vars['title']->value;?>
 - <?php echo $_smarty_tpl->tpl_vars['Name']->value;?>
</TITLE>
</HEAD>
<BODY bgcolor="#ffffff">
<?php }
}
