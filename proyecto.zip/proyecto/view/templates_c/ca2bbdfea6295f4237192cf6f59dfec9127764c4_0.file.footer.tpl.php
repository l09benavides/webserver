<?php
/* Smarty version 3.1.31, created on 2017-11-30 02:19:25
  from "C:\wamp\www\proyecto\view\templates\footer.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5a1f5c9d156896_73325680',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'ca2bbdfea6295f4237192cf6f59dfec9127764c4' => 
    array (
      0 => 'C:\\wamp\\www\\proyecto\\view\\templates\\footer.tpl',
      1 => 1512003421,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5a1f5c9d156896_73325680 (Smarty_Internal_Template $_smarty_tpl) {
?>
</div>
</body>
</html><?php }
}
