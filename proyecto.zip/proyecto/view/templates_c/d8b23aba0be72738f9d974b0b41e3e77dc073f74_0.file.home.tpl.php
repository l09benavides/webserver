<?php
/* Smarty version 3.1.31, created on 2017-11-12 17:02:11
  from "/srv/http/distribuidora/clase1/view/templates/home.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5a087e937c5bd5_87394462',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'd8b23aba0be72738f9d974b0b41e3e77dc073f74' => 
    array (
      0 => '/srv/http/distribuidora/clase1/view/templates/home.tpl',
      1 => 1510185470,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5a087e937c5bd5_87394462 (Smarty_Internal_Template $_smarty_tpl) {
?>
home<?php }
}
