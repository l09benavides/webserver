<?php
/* Smarty version 3.1.31, created on 2017-12-07 01:48:41
  from "C:\wamp\www\proyecto\view\templates\principal.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5a288fe9cc0d92_77295622',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '1c69d7bc779d0cd99dce79c7712cad31b21c65d6' => 
    array (
      0 => 'C:\\wamp\\www\\proyecto\\view\\templates\\principal.tpl',
      1 => 1512607150,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5a288fe9cc0d92_77295622 (Smarty_Internal_Template $_smarty_tpl) {
?>
	<center>Menu</center>
	<br>
	<hr>
	<center>
		<a href="#" onclick="optionMenu(2);">Inicio</a>
		<a href="#" onclick="optionMenu(3);">Crear Usuario</a>
		<a href="#" onclick="optionMenu(4);">Reportes</a>
	</center>

	<div id="contentPrincipal">
		
	</div><?php }
}
