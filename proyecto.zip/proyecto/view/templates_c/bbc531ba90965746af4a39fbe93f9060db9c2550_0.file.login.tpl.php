<?php
/* Smarty version 3.1.31, created on 2017-11-30 02:19:25
  from "C:\wamp\www\proyecto\view\templates\login.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5a1f5c9d12c244_76381201',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'bbc531ba90965746af4a39fbe93f9060db9c2550' => 
    array (
      0 => 'C:\\wamp\\www\\proyecto\\view\\templates\\login.tpl',
      1 => 1512003422,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5a1f5c9d12c244_76381201 (Smarty_Internal_Template $_smarty_tpl) {
?>
<center>
	<table>
		<tr>
			<td>Usuario</td>
			<td><input type="text" id="usuario" required> </td>
		</tr>
		<tr>
			<td>Password</td>
			<td><input type="password" id="password" required></td>
		</tr>
		<tr>
			<td colspan=2>
				<center>
					<input type="button" value="Login" onclick="vallogin();">
				</center>
			</td>
		</tr>
	</table>
</center>

<?php }
}
