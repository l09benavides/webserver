<?php
/* Smarty version 3.1.31, created on 2017-11-02 03:35:14
  from "C:\wamp\www\clase1\view\templates\catalogos.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_59fa846254ac02_46325632',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '1c4cf6f2fdf056dd497dae99c3841297e4e2a35d' => 
    array (
      0 => 'C:\\wamp\\www\\clase1\\view\\templates\\catalogos.tpl',
      1 => 1509585157,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_59fa846254ac02_46325632 (Smarty_Internal_Template $_smarty_tpl) {
?>
catalogos<?php }
}
