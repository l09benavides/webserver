<?php
/* Smarty version 3.1.31, created on 2017-11-30 02:19:24
  from "C:\wamp\www\proyecto\view\templates\header.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5a1f5c9cd3a471_37282224',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'ebede59f0fac84cce2152980f15b09531ce9a88b' => 
    array (
      0 => 'C:\\wamp\\www\\proyecto\\view\\templates\\header.tpl',
      1 => 1512003423,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5a1f5c9cd3a471_37282224 (Smarty_Internal_Template $_smarty_tpl) {
?>
<!DOCTYPE html>
<html>
<head>
	<title>Smarty Project</title>
	<?php echo '<script'; ?>
 type="text/javascript" src="libs/jquery-2.1.1.js"><?php echo '</script'; ?>
><!--Desde el index.php-->
	<?php echo '<script'; ?>
 type="text/javascript">
		function optionMenu (id) {
			$("#content").load("index.php?accion="+id);	
		}
		function vallogin(){
			var usu = $("#usuario").val();
			var pass = $("#password").val();
			$("#content").load("index.php?accion=1&u="+usu+"&p="+pass);	
		}
	<?php echo '</script'; ?>
>
</head>
<body>

<div id="content">
	
<?php }
}
