<?php
/* Smarty version 3.1.31, created on 2017-12-07 03:49:34
  from "C:\wamp\www\proyecto\view\templates\header.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5a28ac3e59f8f6_24066504',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'ebede59f0fac84cce2152980f15b09531ce9a88b' => 
    array (
      0 => 'C:\\wamp\\www\\proyecto\\view\\templates\\header.tpl',
      1 => 1512614948,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5a28ac3e59f8f6_24066504 (Smarty_Internal_Template $_smarty_tpl) {
?>
<!DOCTYPE html>
<html>
<head>
	<title>Smarty Project</title>
	<?php echo '<script'; ?>
 type="text/javascript" src="libs/jquery-2.1.1.js"><?php echo '</script'; ?>
><!--Desde el index.php-->
	<?php echo '<script'; ?>
 type="text/javascript">
		function optionMenu (id) {
			$("#contentPrincipal").load("index.php?accion="+id);	
		}
		function vallogin(){
			var usu = $("#usuario").val();
			var pass = $("#password").val();
			$("#content").load("index.php?accion=1&u="+usu+"&p="+pass);	
		}

		function crearUsuario() {
			var nombre = $("#nombre").val();
			var usu = $("#usuario").val();
			var pass1 = $("#pass1").val();
			var pass2 = $("#pass2").val();
			var perfil = $("#perfil").val();
			var estado = $("#estado").val();
			if (pass1==pass2){
				$("#contentPrincipal").load(
					"index.php?accion=5"+
					"&nombre="+nombre+
					"&usuario="+usu+
					"&pass="+pass1+
					"&perfil="+perfil+
					"&estado="+estado
					);
			}else{
				alert("Deben coincidir las Contraseñas")
			}
		}
	<?php echo '</script'; ?>
>
</head>
<body>

<div id="content">
	
<?php }
}
