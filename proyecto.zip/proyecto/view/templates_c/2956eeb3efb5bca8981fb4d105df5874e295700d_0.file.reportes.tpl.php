<?php
/* Smarty version 3.1.31, created on 2017-11-12 17:02:10
  from "/srv/http/distribuidora/clase1/view/templates/reportes.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5a087e9268e109_05628240',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '2956eeb3efb5bca8981fb4d105df5874e295700d' => 
    array (
      0 => '/srv/http/distribuidora/clase1/view/templates/reportes.tpl',
      1 => 1510185470,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5a087e9268e109_05628240 (Smarty_Internal_Template $_smarty_tpl) {
?>
reportes<?php }
}
