<?php
/* Smarty version 3.1.31, created on 2017-11-12 17:02:09
  from "/srv/http/distribuidora/clase1/view/templates/catalogos.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5a087e91c6ab11_52370523',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '5659dca52a7b95c037d82b0fb87ccfa80bb7d59b' => 
    array (
      0 => '/srv/http/distribuidora/clase1/view/templates/catalogos.tpl',
      1 => 1510185470,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5a087e91c6ab11_52370523 (Smarty_Internal_Template $_smarty_tpl) {
?>
catalogos<?php }
}
