<?php
/* Smarty version 3.1.31, created on 2017-12-07 03:22:33
  from "C:\wamp\www\proyecto\view\templates\frmUsuario.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5a28a5e91b5381_02747615',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'bdcb10569bf2d94da2e85a2b15abb476ed7e118a' => 
    array (
      0 => 'C:\\wamp\\www\\proyecto\\view\\templates\\frmUsuario.tpl',
      1 => 1512613332,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5a28a5e91b5381_02747615 (Smarty_Internal_Template $_smarty_tpl) {
?>
<center>
<h1>Crear Nuevo Usuario</h1>
<br>
	<table width="300px">
		<tr>
			<td width="100px">Nombre</td>
			<td width="200px">
				<input type="text" id="nombre" width="190px">
			</td>
		</tr>
		<tr>
			<td>Usuario</td>
			<td>
				<input type="text" id="usuario" width="190px">
			</td>
		</tr>
		<tr>
			<td>Password</td>
			<td>
				<input type="password" id="pass1" width="190px">
			</td>
		</tr>
		<tr>
			<td>Repetir password</td>
			<td>
				<input type="password" id="pass2" width="190px">
			</td>
		</tr>
		<tr>
			<td>Perfil</td>
			<td>
				<select id="perfil" width="190px">
					<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['Perfiles']->value, 'perfil');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['perfil']->value) {
?>
						<option value="<?php echo $_smarty_tpl->tpl_vars['perfil']->value['ID'];?>
"><?php echo $_smarty_tpl->tpl_vars['perfil']->value['PERFIL'];?>
</option>
					<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);
?>

				</select>
			</td>
		</tr>
		<tr>
			<td>Estado</td>
			<td>
				<select id="estado" width="190px">
					<option value="A">Activo</option>
					<option value="I">Inactivo</option>
				</select>
			</td>
		</tr>
		<tr>
			<td colspan="2">
				<input type="Button" value="Crear Usuario" onclick="crearUsuario();">
			</td>
		</tr>
	</table>
</center><?php }
}
