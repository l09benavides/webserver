<?php
require_once "libs/smarty/config_smarty.php";
require_once "model/perfil_model.php";

class perfil_controller{
	private $insModel;

	public function __construct(){
			$this->insModel = new perfil_model();


			$this->insSmarty = new config_smarty();
			$this->insSmarty->setRutas();
		}

	public function getPerfiles()
	{
		return $this->insModel->getPerfiles();
	}

}

?>