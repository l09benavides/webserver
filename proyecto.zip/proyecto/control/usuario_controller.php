<?php
require_once "libs/smarty/config_smarty.php";
require_once "perfil_controller.php";
require_once "model/usuario_model.php";

class usuario_controller
{

		private $insSmarty;
		private $insPerfil;
		private $insUsuarioModel;

		public function __construct(){
			$this->insPerfil = new perfil_controller();
			$this->insModel = new usuario_model();

			$this->insSmarty = new config_smarty();
			$this->insSmarty->setRutas();
		}

	public function mostrarFrm(){
		$dataPerfiles = $this->insPerfil->getPerfiles();
		$this->insSmarty->setAssign("Perfiles",$dataPerfiles);
		$this->insSmarty->exeDisplay("frmUsuario.tpl");
	}

	public function crearUsuario(){
		if($this->insModel->crearUsuario()){
			echo "Usuario Creado!";
		}else{
			echo "Error creando Usuario!";
		}
	}

	public function ModificarUsuario(){}

	public function BorrarUsuario(){}

}
?>