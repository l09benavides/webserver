<?php
require_once "libs/smarty/config_smarty.php";
require_once "model/login_model.php";

class login_controller
{
	//Singleton
		public static $instancia;
		private $insSmarty;
		private $insLoginModel;

		public static function getInstance(){
			if(!self::$instancia instanceof self){
				return self::$instancia = new self;
			}else{
				return self::$instancia;
			}
		}		

		public function __construct(){
			//al ser orientado a objectos se usa this, y la variable no usa $

			$this->insSmarty = new config_smarty();
			$this->insSmarty->setRutas();

			$this->insLoginModel = new login_model();
		}

	public function mostrarFrm(){
		$this->insSmarty->exeDisplay("header.tpl");
		$this->insSmarty->exeDisplay("login.tpl");
		$this->insSmarty->exeDisplay("footer.tpl");
	}


	public function ValidarLogin($usuario,$passowrd){
		$result = $this->insLoginModel->vallogin($usuario,$passowrd);

		if(result){
			$this->insSmarty->exeDisplay("principal.tpl");
		}else{
			$this->insSmarty->exeDisplay("login.tpl");
		}
	}

}
?>